﻿// La generación de código T4 está habilitada para el modelo 'C:\Users\arcef\Source\Repos\Sistema-Hospitalario3masSistemaYMasHospitalario\Sistema Hospitalario\CapaDatos\Sistema_Hospitalario_BDD.edmx'. 
// Para habilitar la generación de código heredada, cambie el valor de la propiedad del diseñador 'Estrategia de generación de código'
// por 'ObjectContext heredado'. Esta propiedad está disponible en la ventana Propiedades cuando se abre
// el modelo en el diseñador.

// Si no se ha generado ninguna clase de contexto y de entidad, puede que haya creado un modelo vacío pero
// no haya elegido todavía la versión de Entity Framework que se va a usar. Para generar una clase de contexto y clases de entidad
// para el modelo, abra el modelo en el diseñador, haga clic con el botón secundario en la superficie del diseñador y
// seleccione 'Actualizar modelo desde base de datos...', 'Generar base de datos desde modelo...' o 'Agregar elemento de generación
// de código...'.