﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Hospitalario.CapaNegocio.DTOs.HabitacionDTO
{
    public class HabitacionDto
    {
        public int Nro_habitacion { get; set; }
        public int Nro_piso { get; set; }
        public string Tipo_habitacion { get; set; }
    }
}
