﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_Hospitalario.CapaNegocio.DTOs.ProcedimientoDTO
{
    public class MostrarProcedimientoDTO
    {
        public string Nombre { get; set; }
    }
}
