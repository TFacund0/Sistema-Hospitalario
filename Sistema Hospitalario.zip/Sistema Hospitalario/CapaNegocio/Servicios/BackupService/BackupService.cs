﻿using Sistema_Hospitalario.CapaDatos.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Sistema_Hospitalario.CapaNegocio.Servicios.BackupService
{
    public class BackupService
    {
        private readonly IBackupRepository _repo;

        public BackupService(IBackupRepository repo)
        {
            _repo = repo;
        }

        public Task HacerBackupAsync(string destinoBak, IProgress<int> progreso = null, CancellationToken ct = default)
            => _repo.BackupAsync(destinoBak, progreso, ct);

        public Task RestaurarAsync(string origenBak, IProgress<int> progreso = null, CancellationToken ct = default)
            => _repo.RestoreAsync(origenBak, progreso, ct);
    }
}
