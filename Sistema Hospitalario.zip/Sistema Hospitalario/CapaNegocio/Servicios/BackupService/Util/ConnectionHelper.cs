﻿using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;

namespace Sistema_Hospitalario.CapaNegocio.Util
{
    public static class ConnectionHelper
    {
        public static (string providerCnn, string dbName) GetSqlClientCnnFromEntity(string entityConnName)
        {
            var entityCnn = System.Configuration.ConfigurationManager
                            .ConnectionStrings[entityConnName].ConnectionString;

            var ecb = new EntityConnectionStringBuilder(entityCnn);
            var providerCnn = ecb.ProviderConnectionString;

            var sb = new SqlConnectionStringBuilder(providerCnn);
            string dbName = sb.InitialCatalog;

            return (providerCnn, dbName);
        }
    }
}
