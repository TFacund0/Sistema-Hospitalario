﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Sistema_Hospitalario.CapaNegocio.DTOs.InternacionDTO;
using Sistema_Hospitalario.CapaDatos.Interfaces;

namespace Sistema_Hospitalario.CapaDatos.Repositories
{
    public class InternacionRepository : IInternacionRepository
    {
        public InternacionRepository()
        {
        }
        public List<InternacionDto> GetAll()
        {
            using (var db = new Sistema_HospitalarioEntities_Conexion())
            {
                return db.internacion
                    .Select(i => new InternacionDto
                    {
                        Id_paciente = i.id_paciente,
                        Id_medico = i.id_medico,
                        Id_procedimiento = i.id_procedimiento,
                        Fecha_ingreso = i.fecha_inicio,
                        Fecha_egreso = i.fecha_fin,
                        Diagnostico = i.motivo,
                        Nro_habitacion = i.nro_habitacion,
                        Id_cama = i.id_cama,
                        Nro_piso = i.cama.habitacion.nro_piso
                    }).ToList();
            }
        }

        public void Insertar(InternacionDto internacion)
        {
            using (var db = new Sistema_HospitalarioEntities_Conexion())
            {
                var paciente = db.paciente.Find(internacion.Id_paciente);
                
                // Actualizar estado del paciente a "Internado"
                paciente.id_estado_paciente = 1;
                db.Entry(paciente).State = System.Data.Entity.EntityState.Modified;

                // Cama es clave compuesta
                var cama = db.cama.Find(internacion.Id_cama, internacion.Nro_habitacion);
                
                // Actualizar estado de la cama a "Ocupada"
                cama.id_estado_cama = 2;
                db.Entry(cama).State = System.Data.Entity.EntityState.Modified;

                var nuevaInternacion = new internacion
                {
                    id_paciente = internacion.Id_paciente,
                    id_medico = internacion.Id_medico,
                    id_procedimiento = internacion.Id_procedimiento,
                    fecha_inicio = internacion.Fecha_ingreso,
                    fecha_fin = internacion.Fecha_egreso,
                    motivo = internacion.Diagnostico,
                    nro_habitacion = internacion.Nro_habitacion,
                    id_cama = internacion.Id_cama
                };
                db.internacion.Add(nuevaInternacion);
                db.SaveChanges();
            }
        }

        public void Eliminar(int id_internacion)
        {
            using (var db = new Sistema_HospitalarioEntities_Conexion())
            {
                var internacion = db.internacion.Find(id_internacion);
                if (internacion != null)
                {
                    db.internacion.Remove(internacion);
                    db.SaveChanges();
                }
            }
        }

        public void Actualizar(int id_internacion, InternacionDto internacion)
        {
            using (var db = new Sistema_HospitalarioEntities_Conexion())
            {
                var internacionExistente = db.internacion.Find(id_internacion);
                if (internacionExistente != null)
                {
                    internacionExistente.id_paciente = internacion.Id_paciente;
                    internacionExistente.id_medico = internacion.Id_medico;
                    internacionExistente.id_procedimiento = internacion.Id_procedimiento;
                    internacionExistente.fecha_inicio = internacion.Fecha_ingreso;
                    internacionExistente.fecha_fin = internacion.Fecha_egreso;
                    internacionExistente.motivo = internacion.Diagnostico;
                    internacionExistente.nro_habitacion = internacion.Nro_habitacion;
                    internacionExistente.id_cama = internacion.Id_cama;
                    db.Entry(internacionExistente).State = System.Data.Entity.EntityState.Modified;
                    db.SaveChanges();
                }
            }
        }
    }
}
