-- Usuario de moderador con clave hasheada
INSERT INTO usuario (username, password, nombre, apellido, email, id_estado_usuario, id_rol, id_medico)
VALUES ('ejemplo', HASHBYTES('SHA2_256', 'ejemplo1234'), 'ejemplo', 'ejemplo', 'ejemplo@gmail.com', 1, 1, NULL)

/*
	Tener en cuenta que dejamos �nicamente acceso al perfil mod con ese usuario, para luego hacer un Restore del .bak
	Y as� poder obtener los dem�s usuarios registrados en el sistema, junto a toda la informaci�n que fue surgiendo como
	ejemplo en el proyecto.

	Usuarios de Perfiles (con Restore aplicado):
	Gerente:
		usuario: gerente
		contrase�a: gerente1234
	
	Administrativo:
		usuario: admin
		contrase�a: admin1234
	
	Moderador / Administrador:
		usuario: mod
		contrase�a: mod1234
	
	Medico:
		usuario: medico
		contrase�a: medico1234
*/
